import ThemeTest from "../theme-test"

export default function ThemePage() {
  return <ThemeTest />
}
